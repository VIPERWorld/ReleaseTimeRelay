#ifndef ___PID_H__
#define __PID_H__
#include "sys.h"
#include <string.h>
//struct PID
//{
//    s16 SetPoint; // �趨Ŀ�� Desired Value
//    s16 Proportion; // �������� Proportional Const
//    s16 Integral; // ���ֳ��� Integral Const
//    s16 Derivative; // ΢�ֳ��� Derivative Const
//    s32 LastError; // Error[-1]
//    s32 PrevError; // Error[-2]
//    s32 SumError; // Sums of Errors
//};
//extern struct PID spid; // PID Control Structure

//extern void PID_Init(struct PID *pp);
//extern s32 PID_Calc(struct PID *pp, s16 NextPoint);
//extern s32 PID_out; // PID Response (Output)
//extern s32 PID_in; // PID Response (Output)


#endif
