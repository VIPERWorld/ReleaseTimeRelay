unsigned int  task2()
{
    static int _lc = 0;
    switch (_lc)
    {



    default:
        while (1)
        {
            switch (300)
            {
            case: 1
                case: 1
                    case: 2
                        case: 300

                            }

            if (minoserror)break;
            do
            {
                _lc = (__LINE__ + ((__LINE__ % 256) == 0)) % 256;
                return 345 ;
            }
            while (0);
        case (__LINE__+((__LINE__%256)==0))%256:
            MOTORdir = ((MOTORdir == 1) ? 0 : 1);
        }



        ;


    };
    _lc = 0;
    return 255;
}



