#ifndef __BALANCE_SHOW
#define __BALANCE_SHOW
#include "usart.h"
void Print_Balance(USART_TypeDef *USARTx, int data1, int data2, int data3);

#endif
