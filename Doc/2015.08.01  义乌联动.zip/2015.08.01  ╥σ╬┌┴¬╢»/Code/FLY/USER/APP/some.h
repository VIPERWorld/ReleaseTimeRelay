#ifndef __SOME_H_
#define __SOME_H_
#include "sys.h"
extern void some(USART_TypeDef *USARTx);
extern void Data_Receive_Anl(u8 *data_buf, u8 num);
#endif
