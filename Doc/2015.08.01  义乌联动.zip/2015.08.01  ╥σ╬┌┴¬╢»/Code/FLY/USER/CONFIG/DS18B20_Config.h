#ifndef __DS18B20_CONFIG_
#define __DS18B20_CONFIG_

/***ds18b20***/
#define RCC_DS18B20      RCC_APB2Periph_GPIOB
#define LCD_DS18B20_GPIO GPIOB
#define LCD_DS18B20_Pin  GPIO_Pin_0

#define DS18B20_IO_IN()  GPIOB_Init(0,8,PU);//{LCD_DS18B20_GPIO->CRH&=0XFFFFFFF0;LCD_DS18B20_GPIO->CRH|=8<<12;}
#define DS18B20_IO_OUT() GPIOB_Init(0,3,PU);//{LCD_DS18B20_GPIO->CRH&=0XFFFFFFF0;LCD_DS18B20_GPIO->CRH|=3<<12;}

//IO操作函数
#define DS18B20_DQ_OUT PBout(0) //数据端口 PA0 
#define DS18B20_DQ_IN  PBin(0)  //数据端口 PA0 

/***ds18b20***/

#endif
