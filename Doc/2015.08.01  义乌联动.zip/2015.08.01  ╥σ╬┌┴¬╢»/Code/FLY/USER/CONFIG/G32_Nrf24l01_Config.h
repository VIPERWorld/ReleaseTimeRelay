#ifndef _NRF24L01_CONFIG_H_
#define _NRF24L01_CONFIG_H_

/***24L01配置***/
/*使用硬件SPI 1 or 2*/
//#define NRF24L01_SPI1
#define NRF24L01_SPI2
/*使用软件SPI*/
//#define NRF24L01_SPISOFT

/*配置SPI_NRF_SPI的CE引脚*/
#define NRF24l01_CE_RCC  RCC_APB2Periph_GPIOB
#define NRF24l01_CE_GPIO GPIOB
#define NRF24l01_CE_PIN  GPIO_Pin_11
/*配置SPI_NRF_SPI的 CSN 引脚*/
#define NRF24l01_CSN_RCC  RCC_APB2Periph_GPIOC
#define NRF24l01_CSN_GPIO GPIOC
#define NRF24l01_CSN_PIN  GPIO_Pin_6
/*配置SPI_NRF_SPI的IRQ引脚*/
#define NRF24l01_IQR_RCC  RCC_APB2Periph_GPIOC
#define NRF24l01_IQR_GPIO GPIOC
#define NRF24l01_IQR_PIN  GPIO_Pin_7

#ifdef NRF24L01_SPISOFT
	/*配置SPI_NRF_SPI的 MOSI 引脚*/
	#define NRF24l01_MOSI_RCC  RCC_APB2Periph_GPIOB
	#define NRF24l01_MOSI_GPIO GPIOB
	#define NRF24l01_MOSI_PIN  GPIO_Pin_15
	/*配置SPI_NRF_SPI的 SIMO 引脚*/
	#define NRF24l01_SIMO_RCC  RCC_APB2Periph_GPIOB
	#define NRF24l01_SIMO_GPIO GPIOB
	#define NRF24l01_SIMO_PIN  GPIO_Pin_14
	/*配置SPI_NRF_SPI的 SCL(SCK) 引脚*/
	#define NRF24l01_SCL_RCC   RCC_APB2Periph_GPIOB
	#define NRF24l01_SCL_GPIO  GPIOB
	#define NRF24l01_SCL_PIN   GPIO_Pin_13
#endif
/***24L01配置***/

#endif
/*
黑板 黄板
CE  PB11
CSN PC6
IRQ PC7
*/
